# Media3 اور Material اپنے consumer rules ساتھ لاتے ہیں۔
-keepclassmembers class * extends android.webkit.WebViewClient { *; }
-keepclassmembers class * extends android.webkit.WebChromeClient { *; }
