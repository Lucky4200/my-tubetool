package com.litetube.app

import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.fragment.app.Fragment
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButtonToggleGroup
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

@OptIn(UnstableApi::class)
class TvFragment : Fragment() {

    private companion object {
        const val URL_PK = "https://iptv-org.github.io/iptv/countries/pk.m3u"
        const val URL_IN = "https://iptv-org.github.io/iptv/countries/in.m3u"
        const val CACHE_MS = 12 * 3600 * 1000L
        const val DEFAULT_UA =
            "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/124.0.0.0 Mobile Safari/537.36"
    }

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var listContainer: View
    private lateinit var status: TextView
    private lateinit var search: EditText
    private lateinit var adapter: ChannelAdapter

    private var allChannels: List<Channel> = emptyList()
    private var currentKey = ""
    private var isFullscreen = false

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_tv, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        playerView = view.findViewById(R.id.playerView)
        listContainer = view.findViewById(R.id.listContainer)
        status = view.findViewById(R.id.status)
        search = view.findViewById(R.id.search)
        val toggle: MaterialButtonToggleGroup = view.findViewById(R.id.toggle)
        val list: RecyclerView = view.findViewById(R.id.list)

        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(20_000, 60_000, 2_500, 5_000)
            .build()
        val p = ExoPlayer.Builder(requireContext()).setLoadControl(loadControl).build()
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    p.seekToDefaultPosition()
                    p.prepare()
                } else {
                    Toast.makeText(
                        requireContext(), R.string.channel_failed, Toast.LENGTH_SHORT
                    ).show()
                }
            }
        })
        player = p
        playerView.player = p
        playerView.keepScreenOn = true
        playerView.setFullscreenButtonClickListener { fs -> setFullscreen(fs) }

        adapter = ChannelAdapter { ch -> play(ch) }
        list.layoutManager = LinearLayoutManager(requireContext())
        list.adapter = adapter

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = applyFilter()
        })

        toggle.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            if (checkedId == R.id.btnPk) loadChannels("pk", URL_PK)
            else loadChannels("in", URL_IN)
        }
        toggle.check(R.id.btnPk)
    }

    private fun loadChannels(key: String, url: String) {
        currentKey = key
        allChannels = emptyList()
        adapter.submit(emptyList())
        status.visibility = View.VISIBLE
        status.setText(R.string.loading)

        val ctx = requireContext().applicationContext
        Thread {
            val cache = File(ctx.cacheDir, "$key.m3u")
            var text: String? = null

            if (cache.exists() && System.currentTimeMillis() - cache.lastModified() < CACHE_MS) {
                text = cache.readText()
            }
            if (text == null) {
                try {
                    val conn = URL(url).openConnection() as HttpURLConnection
                    conn.connectTimeout = 15_000
                    conn.readTimeout = 20_000
                    val body = conn.inputStream.bufferedReader().use { it.readText() }
                    cache.writeText(body)
                    text = body
                } catch (_: Exception) {
                    if (cache.exists()) text = cache.readText()
                }
            }

            val list = text?.let { M3uParser.parse(it) }
            activity?.runOnUiThread {
                if (view == null || currentKey != key) return@runOnUiThread
                if (list.isNullOrEmpty()) {
                    status.setText(R.string.load_failed)
                } else {
                    allChannels = list
                    status.visibility = View.GONE
                    applyFilter()
                }
            }
        }.start()
    }

    private fun applyFilter() {
        val q = search.text.toString().trim().lowercase()
        adapter.submit(
            if (q.isEmpty()) allChannels
            else allChannels.filter { it.name.lowercase().contains(q) }
        )
    }

    private fun play(ch: Channel) {
        val p = player ?: return
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(15_000)
            .setUserAgent(ch.userAgent ?: DEFAULT_UA)
        ch.referrer?.let { http.setDefaultRequestProperties(mapOf("Referer" to it)) }

        val source = DefaultMediaSourceFactory(http)
            .createMediaSource(MediaItem.fromUri(ch.url))
        p.setMediaSource(source)
        p.prepare()
        p.playWhenReady = true
    }

    private fun setFullscreen(fs: Boolean) {
        isFullscreen = fs
        listContainer.visibility = if (fs) View.GONE else View.VISIBLE
        playerView.layoutParams.height =
            if (fs) ViewGroup.LayoutParams.MATCH_PARENT
            else (220 * resources.displayMetrics.density).toInt()
        playerView.requestLayout()
        (activity as? MainActivity)?.setFullscreenMode(fs)
    }

    fun exitFullscreenIfNeeded(): Boolean {
        if (!isFullscreen) return false
        setFullscreen(false)
        return true
    }

    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        if (hidden) player?.pause()
    }

    override fun onStop() {
        player?.pause()
        super.onStop()
    }

    override fun onDestroyView() {
        player?.release()
        player = null
        super.onDestroyView()
    }

    // ---------------------------------------------------------------

    private class ChannelAdapter(private val onClick: (Channel) -> Unit) :
        RecyclerView.Adapter<ChannelAdapter.VH>() {

        private var items: List<Channel> = emptyList()
        private var selectedUrl: String? = null

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val name: TextView = v.findViewById(R.id.name)
            val group: TextView = v.findViewById(R.id.group)
        }

        fun submit(list: List<Channel>) {
            items = list
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_channel, parent, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val c = items[position]
            h.name.text = c.name
            h.group.text = c.group
            h.group.visibility = if (c.group.isBlank()) View.GONE else View.VISIBLE
            h.itemView.setBackgroundColor(
                if (c.url == selectedUrl) 0xFF2A2A2A.toInt() else Color.TRANSPARENT
            )
            h.itemView.setOnClickListener {
                selectedUrl = c.url
                notifyDataSetChanged()
                onClick(c)
            }
        }
    }
}
