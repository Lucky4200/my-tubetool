package com.litetube.app

data class Channel(
    val name: String,
    val group: String,
    val url: String,
    val referrer: String?,
    val userAgent: String?
)

object M3uParser {

    private val groupRe = Regex("group-title=\"([^\"]*)\"")

    fun parse(text: String): List<Channel> {
        val out = ArrayList<Channel>()
        var name: String? = null
        var group = ""
        var ref: String? = null
        var ua: String? = null

        for (raw in text.lineSequence()) {
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF") -> {
                    name = line.substringAfterLast(',').trim()
                    group = groupRe.find(line)?.groupValues?.get(1) ?: ""
                    ref = null
                    ua = null
                }
                line.startsWith("#EXTVLCOPT:http-referrer=") -> ref = line.substringAfter("=")
                line.startsWith("#EXTVLCOPT:http-user-agent=") -> ua = line.substringAfter("=")
                line.isEmpty() || line.startsWith("#") -> Unit
                else -> {
                    val n = name
                    if (n != null && n.isNotEmpty()) {
                        out.add(Channel(n, group, line, ref, ua))
                    }
                    name = null
                }
            }
        }
        return out
            .distinctBy { it.url }
            .sortedBy { it.name.lowercase() }
    }
}
