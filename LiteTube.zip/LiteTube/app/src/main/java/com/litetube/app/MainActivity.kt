package com.litetube.app

import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    private lateinit var nav: BottomNavigationView
    private lateinit var fullscreenHost: FrameLayout
    private lateinit var yt: Fragment
    private lateinit var music: Fragment
    private lateinit var tv: Fragment

    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        nav = findViewById(R.id.bottomNav)
        fullscreenHost = findViewById(R.id.fullscreenHost)

        val fm = supportFragmentManager
        yt = fm.findFragmentByTag("yt") ?: WebFragment.newInstance("https://m.youtube.com/")
        music = fm.findFragmentByTag("music") ?: WebFragment.newInstance("https://music.youtube.com/")
        tv = fm.findFragmentByTag("tv") ?: TvFragment()

        if (savedInstanceState == null) {
            fm.beginTransaction()
                .add(R.id.container, yt, "yt")
                .add(R.id.container, music, "music").hide(music)
                .add(R.id.container, tv, "tv").hide(tv)
                .commit()
        }

        nav.setOnItemSelectedListener { item ->
            switchTo(
                when (item.itemId) {
                    R.id.nav_youtube -> yt
                    R.id.nav_music -> music
                    else -> tv
                }
            )
            true
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (customView != null) {
                    hideCustomView()
                    return
                }
                val cur = supportFragmentManager.fragments.firstOrNull { it.isVisible }
                if (cur is WebFragment && cur.goBackIfPossible()) return
                if (cur is TvFragment && cur.exitFullscreenIfNeeded()) return
                finish()
            }
        })
    }

    private fun switchTo(target: Fragment) {
        val t = supportFragmentManager.beginTransaction()
        for (f in listOf(yt, music, tv)) {
            if (f === target) t.show(f) else t.hide(f)
        }
        t.commit()
    }

    // ---- WebView کی فل اسکرین ویڈیو ----

    fun showCustomView(view: View, callback: WebChromeClient.CustomViewCallback) {
        if (customView != null) {
            callback.onCustomViewHidden()
            return
        }
        customView = view
        customCallback = callback
        fullscreenHost.addView(
            view,
            ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        fullscreenHost.visibility = View.VISIBLE
        setFullscreenMode(true)
    }

    fun hideCustomView() {
        val v = customView ?: return
        fullscreenHost.removeView(v)
        fullscreenHost.visibility = View.GONE
        customView = null
        customCallback?.onCustomViewHidden()
        customCallback = null
        setFullscreenMode(false)
    }

    /** نیچے کا بار اور سسٹم بار چھپانا، اور آڑی/سیدھی سکرین */
    fun setFullscreenMode(fs: Boolean) {
        nav.visibility = if (fs) View.GONE else View.VISIBLE
        val c = WindowInsetsControllerCompat(window, window.decorView)
        if (fs) {
            c.hide(WindowInsetsCompat.Type.systemBars())
            c.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }
}
