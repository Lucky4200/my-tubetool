package com.litetube.app

import android.net.Uri
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream

/**
 * تین حصوں میں اشتہار بلاک:
 * 1) اشتہاری ڈومین اور URL پیٹرن نیٹ ورک سطح پر بند
 * 2) CSS سے اشتہاری ڈبے چھپانا
 * 3) JavaScript سے ویڈیو اشتہار کو skip / تیز کرنا
 */
object AdBlocker {

    private val blockedHosts = listOf(
        "doubleclick.net",
        "googlesyndication.com",
        "googleadservices.com",
        "adservice.google.com",
        "pagead2.googlesyndication.com",
        "googleads.g.doubleclick.net",
        "static.doubleclick.net",
        "imasdk.googleapis.com",
        "moatads.com",
        "adsafeprotected.com",
        "2mdn.net"
    )

    private val blockedPatterns = listOf(
        "/pagead/",
        "/api/stats/ads",
        "/ptracking",
        "get_midroll_info",
        "/youtubei/v1/player/ad_break",
        "ad_break",
        "&adformat=",
        "?adformat=",
        "/generate_204?ad",
        "ctier=L&"
    )

    fun shouldBlock(uri: Uri): Boolean {
        val host = uri.host ?: return false
        if (blockedHosts.any { host == it || host.endsWith(".$it") }) return true
        val full = uri.toString()
        return blockedPatterns.any { full.contains(it) }
    }

    fun emptyResponse(): WebResourceResponse =
        WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))

    /** ہر پیج پر چلنے والی اسکرپٹ (دوبارہ inject ہو تو خود کو روک لیتی ہے) */
    val JS = """
(function(){
  if (window.__lt) return;
  window.__lt = true;

  var css = '.ytp-ad-module,.ytp-ad-overlay-container,.ytp-ad-overlay-slot,.video-ads,' +
    'ytd-ad-slot-renderer,ytd-in-feed-ad-layout-renderer,ytd-banner-promo-renderer,' +
    'ytd-promoted-sparkles-web-renderer,ytd-display-ad-renderer,ytd-companion-slot-renderer,' +
    'ytd-action-companion-ad-renderer,ytd-player-legacy-desktop-watch-ads-renderer,#masthead-ad,#player-ads,' +
    'ytm-promoted-sparkles-web-renderer,ytm-companion-ad-renderer,ytm-promoted-video-renderer,' +
    'ytm-statement-banner-renderer,ad-slot-renderer,.ad-container,.ad-div,' +
    'ytmusic-mealbar-promo-renderer,ytmusic-statement-banner-renderer' +
    '{display:none !important;}';
  var st = document.createElement('style');
  st.textContent = css;
  (document.head || document.documentElement).appendChild(st);

  function skip(){
    try {
      var p = document.querySelector('.html5-video-player');
      var v = document.querySelector('video.html5-main-video') || document.querySelector('video');
      var ad = p && (p.classList.contains('ad-showing') || p.classList.contains('ad-interrupting'));

      var btn = document.querySelector('.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-skip-ad-button,.ytp-ad-skip-button-container button');
      if (btn) btn.click();

      var close = document.querySelector('.ytp-ad-overlay-close-button');
      if (close) close.click();

      if (ad && v) {
        v.__ltMuted = true;
        v.muted = true;
        v.playbackRate = 16;
        if (isFinite(v.duration) && v.duration > 0) v.currentTime = v.duration;
      } else if (v && v.__ltMuted) {
        v.muted = false;
        v.playbackRate = 1;
        v.__ltMuted = false;
      }
    } catch (e) {}
  }

  setInterval(skip, 300);
  new MutationObserver(skip).observe(document.documentElement, {
    childList: true, subtree: true, attributes: true, attributeFilter: ['class']
  });
})();
""".trimIndent()
}
