# LiteTube

ہلکی ایپ: YouTube، YouTube Music اور پاکستان/انڈیا کے TV چینل۔

## APK کیسے بنائیں
1. GitHub پر نئی repository بنائیں اور یہ پوری فولڈر اپلوڈ کریں (`.github` فولڈر سمیت)۔
2. اوپر **Actions** ٹیب کھولیں، **Build APK** پر جا کر **Run workflow** دبائیں (یا اپلوڈ کے بعد خود چل جائے گی)۔
3. 4 سے 6 منٹ بعد ورک فلو مکمل ہوگا۔ اس پر کلک کریں اور نیچے **Artifacts** سے `LiteTube-APK` ڈاؤن لوڈ کریں۔
4. ZIP کھول کر `app-release.apk` (چھوٹی) یا `app-debug.apk` فون میں انسٹال کریں۔

## چینل لسٹ
iptv-org کی مفت عوامی لسٹ سے آتی ہے:
- پاکستان: https://iptv-org.github.io/iptv/countries/pk.m3u
- انڈیا: https://iptv-org.github.io/iptv/countries/in.m3u
